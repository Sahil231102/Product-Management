package p1;

import java.beans.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**s
 * Servlet implementation class LoginServlet
 */
//@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public LoginServlet() {
        super();
      
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		String umobile= request.getParameter("PhoneNumber");
		String upassword= request.getParameter("password");
		System.out.print("Both Not are same!!!!");
		try
		{
			System.out.print("Enter The code....");
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","abc123");
		
			PreparedStatement psmt = con.prepareStatement("select * from signup where PhoneNumber=? and PASSWORD=?");
			psmt.setString(1, umobile);
			psmt.setString(2, upassword);
			
			ResultSet rs=psmt.executeQuery();
			
			if(rs.next())
			{
				
				response.sendRedirect("homepages.html");
			}
			else
			{
				out.println("<script>alert('incorrect phone number and password Please Enter Vaild')</script>");
				RequestDispatcher rd =request.getRequestDispatcher("/login.html");
				rd.include(request, response);
			}
		}

		
		catch (Exception e) {
			e.printStackTrace();
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
